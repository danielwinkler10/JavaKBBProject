package driver;

import client.SocketClient;


public class DriverFiveClient {
    public static void main(String[] args) {
        SocketClient client = new SocketClient();
        client.run();
    }
}
