package adapter;

public class BuildAuto extends proxyAutomobile implements CreateAuto, UpdateAuto {

}