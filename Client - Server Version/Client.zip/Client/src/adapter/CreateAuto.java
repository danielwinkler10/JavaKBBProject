package adapter;

public interface CreateAuto {
    void BuildAuto(String filename);
    void printAutoMotive(String Modelname);
    void printAuto();
}
