package exception;

public class Fix1to100 {
    Helper help = new Helper();
    //FileNotFound
    protected String fix1(){
        System.out.println("Option Price: ");
        return help.returnString();
    }

    protected String fix2(){
        System.out.println("Option Name: ");
        return help.returnString();
    }
    protected void fix3(){

    }
}
