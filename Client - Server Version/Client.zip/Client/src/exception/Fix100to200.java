package exception;

public class Fix100to200 {
    Helper help = new Helper();
    protected String fix101(){
        System.out.println("Model not found, type correct model name: ");
        return help.returnString();
    }

}
