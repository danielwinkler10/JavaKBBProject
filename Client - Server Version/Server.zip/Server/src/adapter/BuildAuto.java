package adapter;


import server.AutoServer;

public class BuildAuto extends proxyAutomobile implements CreateAuto, UpdateAuto, AutoServer {

}